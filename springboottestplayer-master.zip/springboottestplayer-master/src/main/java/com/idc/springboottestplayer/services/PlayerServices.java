package com.idc.springboottestplayer.services;

import com.idc.springboottestplayer.model.Player;
import com.idc.springboottestplayer.repositories.CountryRepository;
import com.idc.springboottestplayer.repositories.PlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlayerServices {

    @Autowired
    private PlayerRepository pRepository;

    @Autowired
    private CountryRepository cRepository;

    public PlayerServices(PlayerRepository pRepository) {
        this.pRepository = pRepository;
    }


    public List<Player> getPlayers() {
        System.out.println("pRepository.findAll()");
        return pRepository.findAll();
    }

    public List<Player> getPlayersByCountryCode(String countryCode) {
        return pRepository.findByCountryCode(countryCode);
    }

    public List<Player> getPlayersByContinent(String continent) {
        return cRepository.findByContinent(continent);
    }

    public List<Player> getPlayersGreaterThanRating(Integer rating) {
        return pRepository.findByRating(rating);
    }
}
