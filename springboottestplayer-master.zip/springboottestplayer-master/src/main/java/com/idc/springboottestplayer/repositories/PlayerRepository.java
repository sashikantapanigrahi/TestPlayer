package com.idc.springboottestplayer.repositories;

import com.idc.springboottestplayer.model.Player;
import org.springframework.data.jpa.repository.JpaRepository;


import java.util.List;

public interface PlayerRepository extends JpaRepository<Player,String> {
    List<Player> findByCountryCode(String countryCode);
    List<Player> findByRating(Integer rating);

}
